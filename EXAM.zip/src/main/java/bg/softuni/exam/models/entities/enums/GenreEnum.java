package bg.softuni.exam.models.entities.enums;

public enum GenreEnum {
    POP,
    ROCK,
    METAL,
    OTHER
}
