package bg.softuni.exam.models.entities.enums;

public enum ArtistNameEnum {
    QUEEN,
    METALLICA,
    MADONNA
}
